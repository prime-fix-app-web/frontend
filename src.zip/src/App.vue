<script setup>

import LanguageSwitcher from "@/shared/presentation/components/language-switcher.vue";

</script>

<template>
  <div class="app-container">
    <div class="global-language-switcher">
      <language-switcher />
    </div>
    <router-view />
  </div>
</template>

<style>
@import './styles.css';

.app-container {
  position: relative;
  min-height: 100vh;
  width: 100%;
}

.global-language-switcher {
  position: fixed;
  top: 1rem;
  right: 1rem;
  z-index: 1000;
  background: rgba(255, 255, 255, 0.95);
  backdrop-filter: blur(10px);
  border-radius: 12px;
  padding: 0.5rem;
  box-shadow: 0 4px 20px rgba(17, 67, 88, 0.1);
  border: 1px solid rgba(17, 67, 88, 0.05);
}

/* Responsive adjustments */
@media (max-width: 768px) {
  .global-language-switcher {
    top: 0.75rem;
    right: 0.75rem;
    padding: 0.25rem;
  }
}

@media (max-width: 480px) {
  .global-language-switcher {
    top: 0.5rem;
    right: 0.5rem;
  }
}
</style>
